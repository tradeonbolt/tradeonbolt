import os
import sys

# So that we can do `import Ornix AI` in our tests
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

import OrnixAI # noqa: E402

OrnixAI.api_base = os.getenv("SWARMNODE_API_BASE")  # type: ignore
OrnixAI.api_key = os.getenv("SWARMNODE_API_KEY")  # type: ignore
